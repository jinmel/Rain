Instructions
------------

-  Create *configs* and *credentials* folder in working directory.
-  Put *client_secrets.json* file from API console into *configs* folder.
-  Put different *a.png* and *b.png* file in working directory.
